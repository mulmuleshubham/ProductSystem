console.log("this is message on consol")
alert("welcome")